# Code Citations

## License: 未知
https://github.com/BenGreenfield825/TheJudgiesPodWebsite/tree/2e0b6a49cab796946a7a5c0df3b187889adde179/judgies-website/src/components/Video.js

```
.innerHTML = `
          <iframe width="560" height="315" src="https://www.youtube.com/embed/${videoId}" 
          frameborder="0" allowfullscreen></iframe>`;
      })
      .catch((
```

